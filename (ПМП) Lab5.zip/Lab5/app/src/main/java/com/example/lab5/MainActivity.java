package com.example.lab5;

import android.content.Intent;
import android.app.Activity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.PopupMenu;
import android.widget.PopupMenu.OnMenuItemClickListener;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnMenuItemClickListener {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.button)
                //Слідкуємо за натисканням на кнопку:
                .setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //Викликаємо меню, заповнюємо його з файлу popupmenu.xml і налаштовуємо
                        //слухач натискань по пунктам OnMenuItemClickListener:
                        PopupMenu popup_menu = new PopupMenu(MainActivity.this, view);
                        popup_menu.setOnMenuItemClickListener(MainActivity.this);
                        popup_menu.inflate(R.menu.popupmenu);
                        popup_menu.show();
                    }
                });
    }
    //Оброблюємо натискання по пунктам меню, посилаючись на id кожного пункту, заданих у файлі popupmenu.xml
    public boolean onMenuItemClick(MenuItem item) {
        TextView textView = (TextView) findViewById(R.id.TextView);
        switch (item.getItemId()) {
            case R.id.second_page:
                Intent intent = new Intent(this, SecondActivity.class);
                startActivity(intent);
                return true;
            case R.id.about:
                textView.setText("Григорчук Д.С., ІПЗ-17-1");
                return true;
            case R.id.message:
                Toast.makeText(this, "Hello", Toast.LENGTH_SHORT).show();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}