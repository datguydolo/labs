package com.example.lab5;

import android.content.Intent;
import android.app.Activity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.PopupMenu;
import android.widget.PopupMenu.OnMenuItemClickListener;
import android.widget.TextView;
import android.widget.Toast;

public class SecondActivity extends Activity implements OnMenuItemClickListener {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        findViewById(R.id.button2)
                .setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        PopupMenu popup_menu = new PopupMenu(SecondActivity.this, view);
                        popup_menu.setOnMenuItemClickListener(SecondActivity.this);
                        popup_menu.inflate(R.menu.popupmenu_second);
                        popup_menu.show();
                    }
                });
}
    public boolean onMenuItemClick(MenuItem item) {
        TextView textView = (TextView) findViewById(R.id.TextView2);
        switch (item.getItemId())
        {
            case R.id.first_page:
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                return true;
            case R.id.about2:
                textView.setText("Григорчук Д.С., ІПЗ-17-1");
                return true;
            case R.id.message2:
                Toast.makeText(this, "Hello", Toast.LENGTH_SHORT).show();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

